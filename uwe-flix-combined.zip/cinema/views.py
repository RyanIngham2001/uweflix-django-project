from django.shortcuts import render, redirect, get_object_or_404
from .forms import ScreenForm, ShowingForm, FilmForm, CinemaForm, TicketForm
from .models import Screen, Cinema, Film, Showing, Ticket
from booking.models import Cancelation
from authentication.models import User
from utils.custom_decorators import get_user_permissions, is_in_group
from datetime import datetime
# Create your views here.

def create_cinema(request):
    """
    Handle a user creating a cinema.
    
    If the request method is "POST", the function prompts the user to enter cinema information
    before being redirected to the cinema management page if succesful.
    If the request method is not "POST", the cinema form is displayed.
    
    Returns:
        If the request method is "POST" and the form is not valid:
            The cinema form, with the error message passed in as context.
        If the request method is not "POST":
            The cinema form form.
        Otherwise:
            A redirect to the cinema management page.
    """
    perms = get_user_permissions(request)
    if is_in_group(request.user, 'admin'):
        if request.method == "POST":
            form = CinemaForm(request.POST)
            if form.is_valid():
                form.save(commit=True)
                return redirect('manage_screens')
            else:
                form = CinemaForm()
                context = {'form': form, 'user': request.user, 'perms': perms}
                return render(request, 'cinema/create_cinema.html', context)

        form = CinemaForm()        
        context = {'form': form, 'user': request.user, 'perms': perms}
        return render(request, 'cinema/create_cinema.html', context)
    else:
        return redirect('/no_access')

def screen_list(request):
    """
    Handle a screen management page request.
    
    This gets all screen and accompanying model data from the database to pass to the html template.
    
    Returns:
        screen management page with accompanying data
    """
    perms = get_user_permissions(request)
    print(perms)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    screens = Screen.objects.all()
    showings = Showing.objects.all().order_by('start_time')
    cinemas = Cinema.objects.all()
    context = {'user': request.user, 'screens': screens, 'showings': showings, 'cinemas': cinemas, 'perms': perms}
    return render(request, 'cinema/manage_screens.html', context)

def screen_create(request):
    """
    Handle a request to create a new screen.
    
    If the request method is "POST", the function prompts the user to enter screen information 
    before being redirected to the screen management page if succesful.
    If the request method is not "POST", the screen form is displayed.
    
    Returns:
        If the request method is "POST" and the form is not valid:
            The screen form, with the error message passed in as context.
        If the request method is not "POST":
            The screen form form.
        Otherwise:
            A redirect to the screen management page.
    """
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('/no_access')
    
    cinemas = Cinema.objects.all()
    if request.method == 'POST':
        form = ScreenForm(request.POST)
        if form.is_valid():
            screen = form.save()
            form = ScreenForm()
            context = {'form': form, 'user': request.user, 'cinemas': Cinema.objects.all(), 'perms': perms}
            return redirect('manage_screens')
    form = ScreenForm()
    context = {'form': form, 'user': request.user, 'cinemas': Cinema.objects.all(), 'perms': perms}
    return render(request, 'cinema/create_screen.html', context=context)

def screen_update(request, pk):
    """
    Handle a user requesting to update a screen
    
    Returns:
        If the form is invalid:
            screen form
        otherwise:
            redirect to screen management
    """
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('/no_access')
    
    screen = get_object_or_404(Screen, pk=pk)
    if request.method == 'POST':
        form = ScreenForm(request.POST, instance=screen)
        if form.is_valid():
            screen = form.save()
            return redirect('/screen_list')
        
    form = ScreenForm(instance=screen)
    context = {'form': form, 'user': request.user, 'screen': screen, 'perms': perms}    
    return render(request, 'cinema/update_screen.html', context)

def screen_delete(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    screen = get_object_or_404(Screen, pk=pk)
    screen.delete()
    return redirect('screen_list')

def showings_list(request):
    """
    Handle a screen management page request.
    
    This gets all screen and accompanying model data from the database to pass to the html template.
    
    Returns:
        screen management page with accompanying data
    """
    perms = get_user_permissions(request)
    print(perms)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    showings = Showing.objects.all().order_by('start_time')
    context = {'showings': showings, 'perms': perms}
    return render(request, 'cinema/showings_management.html', context)

def showing_create(request):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    films = Film.objects.all()
    screens = Screen.objects.all()

    if request.method == 'POST':
        
        form = ShowingForm(request.POST)
        screen = Screen.objects.get(id = int(form.data.get('screen')))

        print(form.errors)
        if form.is_valid():
            f = form.save(commit=False)
            if not f.social_distancing:
                f.available_seats = screen.seating_capacity
                f.save()
            else:
                f.covid_capacity = screen.seating_capacity / 2
                f.available_seats = f.covid_capacity
                f.save()
            return redirect('manage_screens')
        else:
            print('invalid form')
    form = ShowingForm()
    context = {'form': form, 'user': request.user, 'films': films, 'screens': screens, 'perms': perms}
    return render(request, 'cinema/create_showing.html', context)

def showing_update(request, pk):
    """
    Handle a user requesting to update a showing
    
    Returns:
        If the form is invalid:
            showing form
        otherwise:
            redirect to screen management
    """
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    showing = get_object_or_404(Showing, pk=pk)
    films = Film.objects.all()
    screens = Screen.objects.all()
    if request.method == 'POST':
        form = ShowingForm(request.POST, instance=showing)
        if form.is_valid():
            form.save()
            return redirect('manage_screens')
    form = ShowingForm(instance=showing)
    context = {'form': form, 'user': request.user, 'films': films, 'screens': screens, 'perms': perms}
    return render(request, 'cinema/update_showing.html', context)

def showing_delete(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    showing = get_object_or_404(Showing, pk=pk)
    showing.delete()
    return redirect('manage_screens')

def films_list(request):
    """
    Handle a screen management page request.
    
    This gets all screen and accompanying model data from the database to pass to the html template.
    
    Returns:
        screen management page with accompanying data
    """
    perms = get_user_permissions(request)
    print(perms)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    films = Film.objects.all().order_by('title')
    context = {'films': films, 'perms': perms}
    return render(request, 'cinema/films_management.html', context)

def film_create(request, pk=None):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    if request.method == 'POST':
        form = FilmForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('manage_screens')

    form = FilmForm()
    context = {'form': form, 'user': request.user, 'pk': pk, 'perms': perms}
    return render(request, 'cinema/create_film.html', context)

def film_delete(request, pk):
    perms = get_user_permissions(request.user)
    if perms == '0' or perms == '1':
        return redirect('/no_access')
    
    film = get_object_or_404(Film, pk=pk)
    film.delete()
    return redirect('manage_screens')

def film_showings(request, pk):
    film = get_object_or_404(Film, id=pk)
    showings = Showing.objects.filter(film=film,start_time__gte=datetime.now()).order_by('start_time')
    
    try:
        perms = get_user_permissions(request.user)
        context = {'film': film, 'showings': showings, 'perms': perms}
        return render(request, 'cinema/film_showings.html', context)
    except AttributeError as e:
        context = {'film': film, 'showings': showings}
        return render(request, 'cinema/film_showings.html', context)
    

def users_list(request):
    """
    Handle a user management page request.
    
    This gets all users and accompanying model data from the database to pass to the html template.
    
    Returns:
        screen management page with accompanying data
    """
    perms = get_user_permissions(request)
    print(perms)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    context = {'users' : User.objects.all(), 'user': request.user, 'perms': perms}
    return render(request, 'cinema/user_management.html', context)


def enable_user(request, pk):
    """
    Handle a user activating a user account via the user management page.
    
    Returns:
        A redirect to the user management page.
    """

    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    user = get_object_or_404(User, pk=pk)
    user.is_active = True
    user.save()
    return redirect('user_management')


def disable_user(request, pk):
    """
    Handle a user disabling a user account via the user management page.
    
    Returns:
        A redirect to the user management page.
    """
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    user = get_object_or_404(User, pk=pk)
    user.is_active = False
    user.save()
    return redirect('user_management')

def bookings_list(request):
    """
    Handle a booking management page request.
    
    This gets all bookings and accompanying model data from the database to pass to the html template.
    
    Returns:
        screen management page with accompanying data
    """
    perms = get_user_permissions(request)
    print(perms)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    context = {'cancellations' : Cancelation.objects.all(), 'perms': perms}
    return render(request, 'cinema/manage_cancellations.html', context)

def approve_cancellation(request, pk):
    """
    Handle a user disabling a user account via the user management page.
    
    Returns:
        A redirect to the user management page.
    """
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    booking = get_object_or_404(Cancelation, pk=pk)
    booking.approved = True
    booking.save()
    return redirect('cancellation_management')

def disapprove_cancellation(request, pk):
    """
    Handle a user disabling a user account via the user management page.
    
    Returns:
        A redirect to the user management page.
    """
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    booking = get_object_or_404(Cancelation, pk=pk)
    booking.approved = False
    booking.save()
    return redirect('cancellation_management')

def delete_showing(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    showing = get_object_or_404(Showing, pk=pk)

    # Need to check for related bookings, and decide what to do here. Maybe stripe has a refund?

    showing.delete()
    return redirect('showings_management')


def update_showing(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    if request.method == 'POST':
        form = ShowingForm(request.POST)
        if form.is_valid():
            # If the screen has changed, need to check if there are enough seats in the new screen.
            # If the film has changed, may need to update tickets?
            # If the start time has changed, need to check for conflict with other showings

        #    form.save()
            return redirect('manage_screens')
    
    showing = get_object_or_404(Showing, pk=pk)
    form = ShowingForm(instance=showing)
    context = {'form': form, 'showing': showing, 'perms': perms}  
    return render(request, 'cinema/update_showing.html', context)

def delete_film(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')

    film = get_object_or_404(Film, pk=pk)

    # Need to check for upcoming showings before deletion

    film.delete()

    return redirect('film_management')

def update_film(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    if request.method == 'POST':
        form = FilmForm(request.POST)
        if form.is_valid():
            # If the length has changed, may need to check if showing conflicts are generated
            # If age rating has changed up, check tickets? E.G if gone up to 18, not children

        #    form.save()
            return redirect('manage_screens')
    
    film = get_object_or_404(Film, pk=pk)
    form = FilmForm(instance=film)

    # Need to see how to default fill length and rating
    
    context = {'form': form, 'film': film, 'perms': perms}  
    return render(request, 'cinema/update_film.html', context)


def tickets_list(request):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    context = {'tickets' : Ticket.objects.all(), 'user': request.user, 'perms': perms}
    return render(request, 'cinema/tickets_management.html', context)


def update_ticket(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    ticket = get_object_or_404(Ticket, pk=pk)

    if request.method == 'POST':
        form = TicketForm(request.POST)
        if form.is_valid():
            ticket.ticket_type = form.cleaned_data['ticket_type']
            ticket.price = form.cleaned_data['price']
            ticket.save()
            return redirect('ticket_management')
    
    
    form = TicketForm(instance=ticket)
    context = {'form': form, 'ticket': ticket, 'perms': perms}  
    return render(request, 'cinema/update_ticket.html', context)