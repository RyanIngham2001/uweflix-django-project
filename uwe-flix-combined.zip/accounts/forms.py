from django import forms
from .models import Account, EndOfMonthStatement, StudentDiscountRequest
from clubs.models import Club

class AccountForm(forms.ModelForm):
    class Meta:
        model = Account
        fields = ['discount_rate']
        
class EndOfMonthStatementForm(forms.ModelForm):
    class Meta:
        model = EndOfMonthStatement
        fields = ['date', 'total_spent', 'total_paid', 'outstanding']

class CardForm(forms.Form):
    amount = forms.DecimalField(label = "Top-Up Amount", decimal_places=2, min_value=0,required=True)
    cardNumber = forms.CharField(label = "Card Number", max_length=16, min_length=16, required=True)
    expiryMonth = forms.IntegerField(label = "Expiry Month (number)", max_value=12, min_value=1, required=True)
    expiryYear = forms.IntegerField(label = "Expiry Year", min_value=2000, max_value=3000, required=True)
    cvc = forms.CharField(label = "CVC", max_length=3, min_length=3, required=True)
    cardHolderName = forms.CharField(label = "Cardholder Name", max_length=255, required=True)
    
class StudentDiscountForm(forms.Form):
    class Meta:
        model = StudentDiscountRequest
        fields = ['new_discount_rate', 'reason']