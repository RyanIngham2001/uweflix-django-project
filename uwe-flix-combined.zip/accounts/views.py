from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.conf import settings
from utils.custom_decorators import get_user_permissions, is_in_group
from utils.create_statement import create_statement
from .forms import AccountForm, EndOfMonthStatementForm, CardForm, StudentDiscountForm
from .models import Account, EndOfMonthStatement, UserAccount, CinemaAccount, ClubAccount, StudentDiscountRequest
from clubs.models import Club
from decimal import Decimal


# Create your views here.

def accounts_list(request):
    perms = get_user_permissions(request)
    club_accounts = ClubAccount.objects.all()
    user_accounts = UserAccount.objects.all()
    cinema_accounts = CinemaAccount.objects.all()
    context = {'club_accounts': club_accounts, 'user_accounts': user_accounts, 'cinema_accounts': cinema_accounts, 'perms': perms}
    return render(request, 'accounts/accounts_list.html', context)

def account_create(request):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        print(perms)
        return redirect('no_access')
    
    clubs = Club.objects.all()
    ### USER SUBMITS FORM ###
    if not request.user.groups.all().filter(name='account_manager').exists():
        print(request.user.user_permissions)
        return redirect('no_access')

    if request.method == 'POST':
        # code to handle form submission and create a new account
        form = AccountForm(request.POST)
        print(form.errors)
        if form.is_valid():
            account = form.save(commit=True)
            club = form.cleaned_data['club']
            club.account = account
            club.save()
            return redirect('accounts_list')
        else:
            # render the form with errors
            context = {'form': form, 'user': request.user, 'clubs': clubs, 'perms': perms}
            return render(request, 'accounts/create_account.html', context)
    else:
        ### USER REQUESTS FORM ###
        # render the empty form
        form = AccountForm()
        context = {'form': form, 'user': request.user, 'clubs': clubs, 'perms': perms}
        return render(request, 'accounts/create_account.html', context)


def account_update(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    account = get_object_or_404(Account, pk=pk)
    if request.method == 'POST':
        form = AccountForm(request.POST, instance=account)
        # Check if the form is valid
        if form.is_valid():
            # Save the form and redirect to the club list page
            form.save()
            return redirect('accounts_list')
    # If the request is not POST, or the form is invalid,
    # render the update page with the club instance and the form
    form = AccountForm(instance=account)
    context = {'form': form, 'user': request.user, 'account': account, 'pk': pk, 'perms': perms}
    return render(request, 'accounts/update_account.html', context)


def account_delete(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    account = get_object_or_404(Account, pk=pk)
    account.delete()
    return redirect('accounts_list')

def statements_list(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    account = Account.objects.get(pk=pk)
    statements = EndOfMonthStatement.objects.filter(account__pk=pk)
    print(f'statements: {statements}')
    context = {'user': request.user, 'statements': statements, 'perms': perms}
    return render(request, 'accounts/manage_statements.html', context)


def statement_generate(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    account = Account.objects.get(pk=pk)
    statement = create_statement(account_id=pk)
    statement.save()
    
    statements = EndOfMonthStatement.objects.filter(account__pk=pk)
    context = {'user': request.user, 'statements': statements, 'perms': perms}
    return render(request, 'accounts/manage_statements.html', context)

def statement_update(request, pk, st_pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    account = Account.objects.get(pk=pk)
    statement = EndOfMonthStatement.objects.get(pk=st_pk)
    statements = EndOfMonthStatement.objects.filter(account__pk=pk)
    
    if request.method == 'POST':
        form = EndOfMonthStatementForm(request.POST, instance=statement)
        # Check if the form is valid
        if form.is_valid():
            # Save the form and redirect to the club list page
            amended_statement = form.save()
            new_outstanding = EndOfMonthStatement.update_outstanding(amended_statement.id)
            amended_statement.outstanding = new_outstanding
            amended_statement.save()
            
            context = {'user': request.user, 'statements': statements, 'perms': perms}
            return render(request, 'accounts/manage_statements.html', context)
    # If the request is not POST, or the form is invalid,
    # render the update page with the club instance and the form
    form = EndOfMonthStatementForm(instance=statement)
    context = {'form': form, 'user': request.user, 'account': account, 'pk': pk, 'st_pk': st_pk, 'statement': statement, 'perms': perms}
    return render(request, 'accounts/update_statement.html', context)


def statement_delete(request, pk, st_pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    
    account = Account.objects.get(pk=pk)
    statement = EndOfMonthStatement.objects.get(pk=st_pk)
    statement.delete()
    statements = EndOfMonthStatement.objects.filter(account__pk=pk)
    context = {'user': request.user, 'statements': statements, 'perms': perms}
    return render(request, 'accounts/manage_statements.html', context)


def top_up_balance(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')

    account = get_object_or_404(Account, pk=pk)
    context = {'user': request.user, 'perms': perms}

    if request.method == 'POST':
        amount = request.POST.get('amount')
        cardNumber = request.POST.get("cardNumber")
        expiryMonth = request.POST.get("expiryMonth")
        expiryYear = request.POST.get("expiryYear")
        cvc = request.POST.get("cvc")
        cardHolderName = request.POST.get("cardHolderName")
        
        try:
            decimalised_amount = int(Decimal(amount) * 100)
            
            # TODO: API view instead of create_charge
            
            #response = create_charge(decimalised_amount, cardNumber, expiryMonth, expiryYear, cvc, cardHolderName)
            #print(response)
            # Update the account balance
            account.balance += Decimal(amount)
            account.save()

            messages.success(request, f"{amount} was successfully added to your account balance.")
            return redirect('paymentConfirm')
        except ValueError:
            messages.error(request, 'Invalid amount entered. Please enter a valid number.')
            return redirect('top_up_balance', pk=pk)
            
    form = CardForm()

    return render(request, 'accounts/top_up_balance.html', {'form' : form})

def create_student_discount_request(request, pk):
    perms = get_user_permissions(request)
    if request.method == 'POST':
        student = get_object_or_404(settings.USER_AUTH_MODEL, pk=pk)
        form = StudentDiscountForm(request.POST)
        if form.is_valid():
            student_discount_request = form.save(commit=False)
            student_discount_request.student = student
            student_discount_request.old_discount_rate = student.account.discount_rate
            student_discount_request.save()
            return redirect('index') 
    else:
        form = StudentDiscountForm()
    return render(request, 'clubs/create_student_discount_request.html', {'perms': perms, 'form': form})

def approve_student_discount_request(request, pk):
    perms = get_user_permissions(request)
    if perms == '0' or perms == '1':
        return redirect('no_access')
    discount_request = get_object_or_404(StudentDiscountRequest, pk=pk)
    student = discount_request.student
    student.account.discount_rate = discount_request.discount_rate
    student.account.save()
    discount_request.delete()
    return redirect('index')

def deny_student_discount_request(request, pk):
    pass
