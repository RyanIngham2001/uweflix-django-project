from django.shortcuts import render
from django.conf import settings
from utils.custom_decorators import get_user_permissions, is_in_group
from cinema.models import Film,Showing
from datetime import datetime
import requests
# Create your views here

def index_view(request):
    perms = get_user_permissions(request)
    print(perms)
    films = Film.objects.all()
    showings = Showing.objects.filter(start_time__gte=datetime.now())
    
    for film in films:
        title = film.title.replace(' ', '+')
        url = f'http://www.omdbapi.com/?apikey={settings.OMDB_API_KEY}&t={title}'
        
        response = requests.get(url)
        data = response.json()
        print(data)
        if 'Poster' in data:
            print('poster available')
            film.poster_url = data['Poster']
            film.save()
        else:
            film.poster_url = ''
            
        print(f'poster url : {film.poster_url}')
    
    return render(request, 'utils/index.html', {'user': request.user, 'perms': perms, 'films': films, 'showings':showings})


def view_my_details(request):
    """
    Handle a request for the user to see their details
    
    Returns:
        the users information page
    """
    perms = get_user_permissions(request)
    if request.method == 'GET':
        # Get the current logged-in user
        user = request.user
        # Render the template with the user's details
        return render(request, 'utils/view_details.html', {'user': user, 'perms': perms})