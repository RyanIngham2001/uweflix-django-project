from django.db import models
from cinema.models import Showing, Cinema, Ticket, Film
from accounts.models import Account
from django.conf import settings

# Create your models here.


class Reservation(models.Model):
    id = models.AutoField(primary_key=True)
    showing = models.ForeignKey(Showing, on_delete=models.CASCADE, related_name='showings')
    student_quantity = models.IntegerField()
    adult_quantity = models.IntegerField()
    child_quantity = models.IntegerField()
    booking_cost = models.FloatField()
    reservee = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reservees', default=None)
    cancelled = models.BooleanField(default=False, blank=False, null=False)
    reservee_email = models.EmailField(blank=True, null=True)

class Cancelation(models.Model):
    id = models.AutoField(primary_key=True)
    reservation = models.ForeignKey(Reservation, on_delete=models.CASCADE,related_name='reservation')
    approved = models.BooleanField(default = None, blank= True, null=True)