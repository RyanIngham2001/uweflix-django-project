from django import forms
from .models import Reservation,Showing
from cinema.forms import ShowingForm

class ReservationForm(forms.ModelForm):
    showing = forms.ModelChoiceField(queryset=Showing.objects.all())
    
    class Meta:
        model = Reservation
        fields = ['showing','student_quantity','adult_quantity','child_quantity']
#    def __init__(self, *args, **kwargs):
#        super().__init__(*args, **kwargs)
 #       self.fields['showing'].disabled = True
  #      self.fields['showing'].widget.attrs['readonly'] = True#