from decimal import Decimal
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from.models import Reservation,Showing,Cinema,Cancelation,Ticket,Film
from.forms import ReservationForm,ShowingForm
from .serializers import StripeInformationSerializer
from utils.custom_decorators import get_user_permissions, is_in_group
import requests
from datetime import datetime
import pytz
from django.conf import settings

class StripeInformation(object):
    def __init__(self, name, description, unit_amount, quantity):
        self.name = name
        self.description = description
        self.unit_amount = unit_amount
        self.quantity = quantity

#View to create a booking
def make_booking(request, pk=None):
    form = ReservationForm()
    if pk:
        form.fields['showing'].initial = Showing.objects.get(id = pk)
    # If the submit button is pressed
    if request.method == 'POST':
        # Create a temp form to get the selected showing
        temp_form = form = ReservationForm(request.POST)
        print(temp_form.data)
        showing = Showing.objects.get(id=int(temp_form.data.get("showing")))
        film = get_object_or_404(Film, pk=showing.film_id)
        cinema = Cinema.objects.get(id=int(showing.screen.cinema.id))
        adultTicket = Ticket.objects.get(pk=1)
        studentTicket = Ticket.objects.get(pk=2)
        childTicket = Ticket.objects.get(pk=3)

        # Calculate the cost of the order based on the ticket pricing in the ticket model
        if request.user.is_authenticated:
            student_cost = Decimal(temp_form.data['student_quantity']) * Decimal(studentTicket.price) * Decimal(1 - request.user.discount_rate)
        else:    
            student_cost = Decimal(temp_form.data['student_quantity']) * Decimal(studentTicket.price)
        child_cost = Decimal(temp_form.data['child_quantity']) * Decimal(childTicket.price)
        adult_cost = Decimal(temp_form.data['adult_quantity']) * Decimal(adultTicket.price)
        total_cost = student_cost + child_cost + adult_cost

        # Create the final form with the reservee and cost added
        if request.user.is_authenticated:
            model = Reservation(reservee=request.user, booking_cost=total_cost)
        else:
            model = Reservation(reservee=None, booking_cost=total_cost, reservee_email='')
        form = ReservationForm(request.POST, request.FILES, instance=model)

        # If the form is all correct, save the booking, update the amount of tickets and redirect to checkout

        if form.is_valid() and showing.start_time >= pytz.utc.localize(datetime.now()):
            total_seats = int(form.data.get("student_quantity")) + int(form.data.get("adult_quantity")) + int(form.data.get("child_quantity"))

            # If not a logged in user, need to redirect to payment page for card details and order confirmation
            if not request.user.is_authenticated:
                if int(showing.available_seats) >= total_seats:
                    student_quantity = temp_form.data['student_quantity']
                    child_quantity = temp_form.data['child_quantity']
                    adult_quantity = temp_form.data['adult_quantity']

                    order_items = []

                    # Creates the product data to be passed to the Stripe Payments app for checkout
                    if (int(child_quantity) > 0):
                        order_items.append(
                            StripeInformation(
                            'Child Ticket', 
                            ('Child ticket for the showing of ' + film.title + ' at ' + str(showing.start_time)),
                            (int(childTicket.price * 100)),
                            (int(child_quantity))
                            )
                        )

                    if (int(student_quantity) > 0):
                        order_items.append(
                            StripeInformation(
                            'Student Ticket', 
                            ('Student ticket for the showing of ' + film.title + ' at ' + str(showing.start_time)),
                            (int(studentTicket.price * 100)),
                            (int(student_quantity))
                            )
                        )

                    if (int(adult_quantity) > 0):
                        order_items.append(
                            StripeInformation(
                            'Adult Ticket', 
                            ('Adult ticket for the showing of ' + film.title + ' at ' + str(showing.start_time)),
                            (int(adultTicket.price * 100)),
                            (int(adult_quantity))
                            )
                        )
                    
                    serializer = StripeInformationSerializer(order_items, many=True)

                    response = requests.post('http://localhost:8000/api/create_checkout_session/', json=serializer.data)
                    response_dict = response.json()

                    ###### Need to handle placing the booking after payment ####
                    return redirect(response_dict['url'])

            if int(showing.available_seats) >= total_seats and request.user.account.balance > total_cost:  
                # Save the booking
                booking = form.save(commit=False)
                booking.showing = showing
                booking.save()

                # Update the available seats
                showing.available_seats = int(showing.available_seats) - total_seats
                showing.save()

                return redirect('view_bookings')

    context = {
        'form': form,
    }
    return render(request, 'make_booking.html', context)

def request_cancelation(request, pk):
    reservation = Reservation.objects.get(id=pk)
    cancelation = Cancelation(reservation=reservation)

    cancelation.save()

    return redirect('view_bookings')

#View for viewing all of the bookings relating to the account
def view_bookings(request):
    perms = get_user_permissions(request)
    try:
        #Get all bookings for the current user
        upcoming_bookings = Reservation.objects.filter(reservee = request.user,showing__start_time__gte =datetime.now()).order_by('-showing__start_time')
        past_bookings = Reservation.objects.filter(reservee = request.user,showing__start_time__lte =datetime.now()).order_by('-showing__start_time')
        cancelations = Cancelation.objects.all()
        context = {
            'upcoming_bookings':upcoming_bookings,
            'past_bookings':past_bookings,
            'cancelations':cancelations,
            'perms': perms,
        }
        return render(request, 'view_bookings.html',context)
    #If an error occurs or if user isn't logged in, redirect to no access page
    except:
        return redirect('/no_access')