from django.urls import path

from . import views

app_name = 'stripePayments'

urlpatterns = [
    path('payment_confirm/', views.payment_confirm, name='payment_confirm'),
    path('create_checkout_session/', views.CheckoutSessionView.as_view(), name='create_checkout_session'),
]