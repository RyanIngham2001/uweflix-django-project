from django.apps import AppConfig


class StripepaymentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'stripePayments'
