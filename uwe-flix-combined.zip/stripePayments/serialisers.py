from rest_framework import serializers
from .models import StripeCharge, StripeReceipt

class StripeChargeSerialiser(serializers.ModelSerializer):
    class Meta:
        model = StripeCharge
        fields = '__all__'
        
class StripeReceiptSerialiser(serializers.ModelSerializer):
    class Meta:
        model = StripeReceipt
        fields = '__all__'

class StripeInformationSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=255)
    description = serializers.CharField(max_length=255)
    unit_amount = serializers.IntegerField()
    quantity = serializers.IntegerField()

    def create(self, validated_data):
        from .views import StripeInformation
        return StripeInformation(**validated_data)