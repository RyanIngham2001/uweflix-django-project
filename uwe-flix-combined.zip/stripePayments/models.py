from django.db import models
from accounts.models import Account

# Create your models here.


class StripeCharge(models.Model):
    charge_id = models.DecimalField(max_digits=10, decimal_places=2)
    
class StripeReceipt(models.Model):
    charge = models.ForeignKey(StripeCharge, related_name='charge', on_delete=models.PROTECT)
    email = models.EmailField(max_length=255, default=None)
    
    