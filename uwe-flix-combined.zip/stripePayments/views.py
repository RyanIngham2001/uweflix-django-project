from django.shortcuts import render, redirect
from django.conf import settings
from django.http.response import JsonResponse
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
import stripe
from .models import StripeCharge, StripeReceipt
from .serialisers import StripeChargeSerialiser, StripeReceiptSerialiser, StripeInformationSerializer
# Create your views here.

class StripeInformation(object):
    def __init__(self, name, description, unit_amount, quantity):
        self.name = name
        self.description = description
        self.unit_amount = unit_amount
        self.quantity = quantity

class StripePaymentView(APIView):
    def post(self, request):
        stripe.api_key = settings.STRIPE_SECRET_KEY

        # Extract the payment amount and payment method ID from the request
        amount = request.data.get('amount')
        payment_method_id = request.data.get('payment_method_id')

        try:
            # Create a PaymentIntent with the specified amount and payment method ID
            payment_intent = stripe.PaymentIntent.create(
                amount=amount,
                currency='usd',
                payment_method=payment_method_id,
                confirmation_method='manual',
                confirm=True
            )

            # Return the client secret of the PaymentIntent to the frontend
            return Response({'client_secret': payment_intent.client_secret})

        except stripe.error.CardError as e:
            # If the payment is declined, return an error message
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class CheckoutSessionView(APIView):
    def post(self, request):
        domain_url = 'http://localhost:8000/'
        stripe.api_key = settings.STRIPE_SECRET_KEY
        
        data = request.data
        serializer = StripeInformationSerializer(data = request.data, many = True)

        if serializer.is_valid():
            serializer.save()
        else:
            return Response(status=status.HTTP_400_BAD_REQUEST)
        
        line_items = []
        for item in serializer.data:
            line_items.append(
                {
                    'price_data': {
                    'currency': 'gbp',
                    'product_data': {
                    'name': item['name'],
                    'description': item['description'],
                    },
                    'unit_amount': item['unit_amount'],
                    },
                'quantity': item['quantity'],
                }
            )

        try:
            checkout_session = stripe.checkout.Session.create(
            client_reference_id=request.user.id if request.user.is_authenticated else None,
            success_url=domain_url + 'paymentConfirm?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=domain_url,
            payment_method_types=['card'],
            mode='payment',
            line_items = line_items
            )
            return Response({'session_id': checkout_session.id, 'url': checkout_session.url}, status=status.HTTP_201_CREATED)

        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


def payment_confirm(request):
    return render(request, 'paymentConfirm.html')
